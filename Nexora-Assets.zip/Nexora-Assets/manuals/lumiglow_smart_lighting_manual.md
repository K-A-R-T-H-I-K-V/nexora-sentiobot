# Nexora LumiGlow Smart Light – User Manual
**Model: NL-RGBW-E27-V2**

## 1. Introduction
Welcome to the Nexora smart home ecosystem. The *LumiGlow Smart Light* is engineered to provide vibrant, responsive, and energy-efficient illumination. This manual will guide you through setup, advanced features, and troubleshooting to ensure you get the most out of your smart lighting experience.

---

## 2. What's in the Box
- 1 x LumiGlow Smart Light (E27 Base)
- 1 x Quick Start Guide
- 1 x Warranty Card

---

## 3. Safety & Compliance
**WARNING: Read all safety instructions before installation to prevent injury and device damage.**

### 3.1 Electrical Safety
- **Risk of Electric Shock.** Disconnect power at the circuit breaker or light switch before installing or servicing the bulb.
- For indoor use only. Do not expose the device to water or moisture, as this can cause damage and create a shock hazard.
- Operate only in fixtures rated for this bulb's wattage (9W). Do not use in fully enclosed fixtures, as this can lead to overheating and shorten the bulb's lifespan.
- Not for use with standard dimmer switches. Dimming is controlled exclusively via the Nexora Home App or compatible voice assistants. Using a physical dimmer may damage the bulb's internal electronics.

### 3.2 FCC Compliance Statement
This device complies with Part 15 of the FCC Rules. Operation is subject to the following two conditions: (1) this device may not cause harmful interference, and (2) this device must accept any interference received, including interference that may cause undesired operation.

---

## 4. Installation & Initial Setup

### 4.1 Physical Installation
1.  **Turn Off Power:** Ensure the light switch for the intended socket is in the OFF position. For maximum safety, turn off the corresponding circuit breaker.
2.  **Install Bulb:** Gently screw the LumiGlow bulb into the standard E27 socket until it is snug. Do not overtighten.
3.  **Turn On Power:** Restore power by flipping the light switch and/or circuit breaker back ON.
4.  **Enter Pairing Mode:** The bulb should immediately begin to blink slowly (pulsing white light), indicating it is in pairing mode and ready to be added to the Nexora Home App. If it does not blink, proceed to the "Forcing Pairing Mode" step in the Troubleshooting section.

### 4.2 App Connectivity
1.  **Download App:** If you haven't already, download the **Nexora Home App** from the Google Play Store or Apple App Store.
2.  **Add Device:** Open the app, tap the '+' icon in the top right corner, and select "Add Device".
3.  **Select Light:** Choose "LumiGlow Smart Light" from the list of available devices.
4.  **Connect to Wi-Fi:** Follow the on-screen instructions to connect the bulb to your **2.4 GHz Wi-Fi network**. 5 GHz networks are not supported for initial setup. Ensure your phone is connected to the same 2.4 GHz network.
5.  **Finalize:** Once connected, you can assign the bulb to a room, give it a custom name (e.g., "Living Room Lamp"), and begin controlling it from the app.

---

## 5. Advanced Features

### 5.1 Voice Integration
Integrate your LumiGlow lights with major voice assistants for hands-free control.
-   **Setup:** In the Nexora Home App, go to `Me > More Services` and select Amazon Alexa or Google Assistant. Follow the prompts to link your Nexora account.
-   **Sample Commands:**
    -   *"Alexa, set the bedroom light to 50% brightness."*
    -   *"Hey Google, turn the kitchen lights to warm white."*
    -   *"Alexa, make the office light purple."*

### 5.2 Scenes & Automation
-   **Scenes:** Create and save custom lighting presets. For example, a "Movie Night" scene could dim all lights to 20% and set them to a deep blue color. Access this via the `Scenes` tab in the app.
-   **Schedules:** Automate your lighting based on time of day. Set your lights to slowly brighten in the morning as a wake-up light or turn off automatically when you leave for work. Configure this under `Device Settings > Schedules`.

### 5.3 Firmware Updates
We periodically release firmware updates to improve performance and add new features.
-   **How to Update:** The Nexora Home App will display a notification on the device's page if an update is available. Tap the notification and follow the on-screen instructions.
-   **Important:** Do not turn off the light or disconnect it from power during a firmware update, as this can render the device inoperable.

---

## 6. In-Depth Troubleshooting
This section covers common issues and their solutions. Always attempt these steps before contacting support.

### 6.1 Connectivity Issues
-   **Problem:** Bulb is not entering pairing mode (not blinking).
    -   **Solution:** Perform a manual reset. With the light switch ON, quickly toggle it OFF and ON three times in a row (OFF-ON, OFF-ON, OFF-ON). The bulb should begin blinking rapidly, then slowly, indicating it has entered pairing mode.

-   **Problem:** Nexora app cannot find the bulb during setup.
    -   **Solution 1 (Wi-Fi):** Confirm your smartphone is connected to a **2.4 GHz Wi-Fi network**. Smart devices cannot connect to 5 GHz networks for setup.
    -   **Solution 2 (Proximity):** Move your smartphone closer to the light bulb during the pairing process.
    -   **Solution 3 (Interference):** Temporarily disable any active VPNs on your phone and ensure your router's firewall isn't blocking new device connections.

-   **Problem:** Bulb frequently disconnects from the network (shows as "Offline" in the app).
    -   **Solution 1 (Signal Strength):** Your bulb may be too far from your Wi-Fi router. Check the signal strength in the app under `Device Settings > Network Info`. Consider moving your router or using a Wi-Fi extender.
    -   **Solution 2 (Router Congestion):** Your router may have too many devices connected. Try rebooting your router by unplugging it for 30 seconds and plugging it back in.

### 6.2 Performance Issues
-   **Problem:** The light is flickering.
    -   **Solution 1 (Socket):** Ensure the bulb is screwed snugly into the socket. A loose connection can cause flickering.
    -   **Solution 2 (Incompatible Hardware):** Confirm the light is NOT connected to a physical dimmer switch. These are incompatible and will cause flickering and damage.

-   **Problem:** Colors are inaccurate or mismatched with the app's color wheel.
    -   **Solution:** This is often a firmware issue. Check for and install the latest firmware update as described in section 5.3.

-   **Problem:** The bulb is unresponsive to app or voice commands.
    -   **Solution 1 (Reboot):** Turn the light off at the physical switch, wait 10 seconds, and turn it back on. This will reboot the bulb's internal module and may restore connectivity.
    -   **Solution 2 (Factory Reset):** If rebooting fails, perform a factory reset. Toggle the light switch OFF and ON five times in a row. The bulb will flash multiple colors and then reset to a steady white, indicating a successful factory reset. **Note:** This will erase all settings and you will need to re-add the device to your app.

---

## 7. Technical Specifications
-   **Wattage:** 9W LED (60W incandescent equivalent)
-   **Luminosity:** 800 Lumens
-   **Connectivity:** Wi-Fi (IEEE 802.11 b/g/n, 2.4GHz), Bluetooth 4.2
-   **Color Options:** 16+ million RGB, Tunable White (2700K - 6500K)
-   **Expected Lifespan:** 25,000 hours
-   **Socket:** E27 Standard Screw Base
-   **Operating Voltage:** 220-240V ~ 50/60Hz

---

## 8. Warranty & Support
-   **Warranty:** This product is covered by a 1-year limited manufacturer's warranty from the date of purchase. The warranty covers defects in materials and workmanship under normal use. It does not cover damage caused by misuse, accidents, or installation with incompatible hardware (e.g., dimmer switches).
-   **Support:** For troubleshooting, FAQs, and warranty claims, please visit our official support portal at **www.nexoraelectronics.com/support** or call our customer service line at **1800-123-NEXORA**. Please have your product's model number and proof of purchase available when contacting support.