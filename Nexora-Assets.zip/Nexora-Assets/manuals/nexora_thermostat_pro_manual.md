# Nexora Thermostat Pro – User Manual
**Model: NTS-PRO-24V-V3**

## 1. Introduction
Thank you for choosing the Nexora Thermostat Pro, the next generation of intelligent climate control. Engineered for maximum energy efficiency and seamless integration into your smart home, the Thermostat Pro ensures your comfort while actively working to reduce your power consumption. This manual provides comprehensive instructions for installation, operation, and troubleshooting.

---

## 2. What's in the Box
- 1 x Nexora Thermostat Pro Display Unit
- 1 x Wall-Mount Base Plate
- 1 x Trim Plate (for covering old paint marks)
- 2 x Wall Screws & Anchors
- 1 x Set of Wire Labels
- 1 x Installation & Quick Start Guide
- 1 x Warranty Card

---

## 3. Safety & Compliance
**WARNING: RISK OF ELECTRICAL SHOCK. Turn off power to your HVAC system at the circuit breaker box before beginning installation to prevent serious injury.**

### 3.1 Pre-Installation Warnings
-   This thermostat is designed for use with 24V AC low-voltage systems. It is **NOT** compatible with high-voltage systems (120/240V), such as electric baseboard heaters.
-   If you are unsure about your HVAC system's compatibility, consult a professional HVAC technician.
-   A **C-wire (Common wire)** is highly recommended for stable performance. While the Thermostat Pro can operate in some systems without a C-wire, its absence may lead to battery drain and connectivity issues.
-   Read all instructions carefully before proceeding. Nexora is not responsible for damage caused by improper installation.

### 3.2 FCC Compliance
This device complies with Part 15 of the FCC Rules. Operation is subject to the following two conditions: (1) this device may not cause harmful interference, and (2) this device must accept any interference received, including interference that may cause undesired operation.

---

## 4. Installation Guide
*Tools Required:* Phillips Screwdriver, Drill with small bit (optional), Smartphone with Nexora App.

### 4.1 Removing Your Old Thermostat
1.  **Power Off HVAC:** Go to your home's main electrical panel and turn off the circuit breaker that controls your heating and air conditioning system.
2.  **Remove Old Cover:** Gently pull the cover off your old thermostat. Most models snap off or have small tabs.
3.  **Photograph & Label Wires:** Before disconnecting any wires, take a clear photo of the current wiring configuration. Use the included wire labels to mark each wire according to the terminal it's connected to (e.g., R, C, W, Y, G).
4.  **Disconnect Wires & Base:** Carefully unscrew the terminals and disconnect the wires. Unscrew the old thermostat's base plate from the wall.

### 4.2 Wiring the Thermostat Pro
1.  **Mount Base Plate:** Use the new Thermostat Pro base plate and screws to mount it to the wall. Use the optional trim plate if needed to cover any gaps or old paint.
2.  **Connect Wires:** Insert each labeled wire into the corresponding terminal on the Thermostat Pro base plate. The terminals are push-in; no screwdriver is needed.
    -   `R` or `Rh`/`Rc`: Power
    -   `C`: Common wire (Provides continuous power)
    -   `W` or `W1`: Heating
    -   `Y` or `Y1`: Cooling
    -   `G`: Fan control

3.  **Attach Display:** Align the display unit with the base plate and gently push until it clicks securely into place.
4.  **Restore Power:** Turn the circuit breaker for your HVAC system back ON. The Thermostat Pro display should power on and begin the initial setup sequence.

---

## 5. App Setup & Configuration
1.  **Download App:** Install the **Nexora Home App** from the Google Play Store or Apple App Store.
2.  **Add Device:** Open the app, create an account or log in, and select `Add New Device > Thermostat Pro`.
3.  **Connect to Wi-Fi:** The thermostat display will show a QR code. Scan it with the app and follow the on-screen instructions to connect to your **2.4 GHz Wi-Fi network**.
4.  **System Configuration:** The app will guide you through a series of questions about your HVAC system (e.g., fuel type, heating type) to optimize performance.
5.  **Integrate Voice Assistants:** In the app, navigate to `Settings > Integrations` to link your Nexora account with Amazon Alexa or Google Home.

---

## 6. Advanced Features
-   **Adaptive Learning:** During the first week of use, the Thermostat Pro learns your schedule and temperature preferences to build an automatic, energy-saving schedule.
-   **Energy Reports:** View detailed daily and monthly energy consumption reports in the app to track your savings and usage patterns.
-   **Vacation Mode:** Set a specific temperature range for when you are away to save energy without turning the system completely off.
-   **Filter Reminders:** The thermostat tracks your HVAC system's runtime and will remind you when it's time to change the air filter.

---

## 7. In-Depth Troubleshooting

| Symptom / Error Code | Possible Cause(s)                                   | Solution / Action                                                                                                                                                             |
| -------------------- | --------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Display is blank     | No power from HVAC system; C-wire not connected properly. | 1. Ensure the HVAC circuit breaker is ON. 2. Double-check that all wires, especially **R** and **C**, are securely seated in the terminals. 3. Confirm your HVAC drip pan or drain is not clogged, as this can trigger a safety shut-off switch. |
| Wi-Fi won't connect (Error E1) | Incorrect password; Router issue; 5 GHz network selected. | 1. Verify your Wi-Fi password is correct. 2. Ensure you are connecting to a **2.4 GHz** network, not 5 GHz. 3. Reboot your router by unplugging it for 30 seconds. 4. Move your router closer to the thermostat if the signal is weak. |
| Heating/Cooling won't turn on | Incorrect wiring; System configuration error. | 1. Re-check your wiring against the photo of your old thermostat. Ensure the `W` wire is in the `W` terminal and `Y` is in the `Y` terminal. 2. Go to `App Settings > Thermostat > System Configuration` and verify your HVAC type is set correctly. |
| Temperature seems inaccurate | Thermostat needs calibration; Drafts or direct sunlight. | 1. Go to `App Settings > Calibration` and adjust the temperature offset. 2. Ensure the thermostat is not located in direct sunlight, near a window, or in a drafty area, as this will affect its readings. |
| Screen is frozen or unresponsive | Temporary software glitch. | Press and hold the physical reset button on the side of the display unit for 15 seconds until the screen reboots. This will not erase your settings. |
| Short Cycling (HVAC turns on/off rapidly) | Advanced setting misconfiguration. | This can damage your HVAC system. In the app, go to `Settings > Advanced > Cycle Rate` and ensure it is set to the recommended value for your system type (e.g., 5 cycles/hour for forced air). If unsure, contact a professional. |

---

## 8. Technical Specifications
-   **Power Requirement:** 24V AC via terminals `R` and `C`
-   **Wire Terminal Compatibility:** R, Rc, Rh, C, W, W2, Y, Y2, G, O/B
-   **Display:** 4-inch, 480x480 pixel color LCD touchscreen
-   **Sensors:** Temperature, Humidity, Proximity
-   **Connectivity:** Wi-Fi 802.11 b/g/n @ 2.4GHz, Bluetooth 5.0
-   **Operating Temperature:** 0°C to 50°C (32°F to 122°F)
-   **Certifications:** UL, FCC, IC

---

## 9. Warranty & Support
-   **Warranty:** Nexora provides a **2-year limited manufacturer's warranty** from the date of purchase. This covers defects in materials and workmanship. Damage from improper installation, power surges, or physical abuse is not covered.
-   **Support:** For our full knowledge base, video tutorials, and to submit a support ticket, please visit **www.nexoraelectronics.com/support**. For urgent assistance, call **1800-123-NEXORA**.
-   **Requirement:** Proof of purchase (receipt or order confirmation) is required to initiate any warranty service.