# Nexora SecureSphere 360 Camera – User Manual
**Model: NCS-360-OD-V2**

## 1. Introduction
Welcome to Nexora's advanced security ecosystem. The *SecureSphere 360 Camera* is designed to provide comprehensive surveillance with its panoramic lens and AI-powered intelligence. Suitable for both indoor and outdoor environments, it ensures you never miss a moment. This manual details the setup, advanced features, and in-depth troubleshooting for your device.

---

## 2. What's in the Box
- 1 x SecureSphere 360 Camera Unit
- 1 x Weatherproof Power Adapter (3m / 10ft cable)
- 1 x Wall Mounting Plate & Hardware Kit (screws, anchors)
- 1 x Mounting Position Sticker
- 1 x Reset Pin
- 1 x Quick Start Guide & Warranty Card

---

## 3. Safety, Placement & Privacy
**WARNING: Please read all guidelines before installation to ensure optimal performance and safety.**

### 3.1 Power & Placement
-   Use only the supplied power adapter. Using a third-party adapter may damage the device and void the warranty.
-   The camera is weather-resistant (IP65 rated), not fully waterproof. It can withstand rain and dust but should not be submerged in water. For best results, install it in a sheltered outdoor location, such as under an eave.
-   Avoid pointing the camera lens directly into the sun, as this can damage the image sensor over time.
-   For optimal AI detection, mount the camera 2.5-3 meters (8-10 ft) above the ground.

### 3.2 Privacy & Legal Compliance
-   Be aware of local privacy laws regarding video and audio recording. You may be required to notify individuals that they are being recorded.
-   Do not install the camera in areas where there is a reasonable expectation of privacy, such as bathrooms or looking into a neighbor's property.
-   Utilize the "Privacy Mode" feature when you are home to disable recording.

---

## 4. Installation & Initial Setup

### 4.1 Physical Installation
1.  **Select Location:** Choose a location with a clear, unobstructed view and a strong Wi-Fi signal.
2.  **Insert microSD Card (Optional):** Gently open the weatherproof seal on the bottom of the camera and insert a Class 10 microSD card (up to 128GB, sold separately) for local video storage. Close the seal firmly.
3.  **Mount the Camera:**
    * **Shelf:** Place the camera on any flat, stable surface.
    * **Wall/Ceiling:** Use the included mounting position sticker to mark drill holes. Drill pilot holes, insert the wall anchors, and screw the mounting plate into place. Attach the camera to the plate.
4.  **Connect Power:** Route the power cable and plug it into a weatherproof outlet.
5.  **Check LED Indicator:** The camera's LED will turn solid red, then begin blinking blue, indicating it is powered on and ready for app setup.

### 4.2 App Connectivity
1.  **Download App:** Install the **Nexora Home App** from the Google Play Store or Apple App Store.
2.  **Add Device:** Open the app and tap the `+` icon, then select `Add Device > SecureSphere 360 Camera`.
3.  **Connect to Wi-Fi:** Ensure your phone is connected to a **2.4 GHz Wi-Fi network**. Follow the app's instructions to enter your Wi-Fi password.
4.  **Scan QR Code:** A QR code will appear on your phone's screen. Hold your phone 15-20 cm (6-8 inches) in front of the camera lens. The camera will emit a chime sound upon a successful scan.
5.  **Finalize:** Once connected, name your camera (e.g., "Driveway Camera"), assign it to a room, and configure your initial settings.

---

## 5. Advanced Features
-   **AI Detection Zones:** In the app, go to `Device Settings > Detection Settings > Activity Zones`. Draw specific areas in the camera's view where you want to receive motion alerts (e.g., your walkway, but not the public sidewalk). This drastically reduces false notifications.
-   **Privacy Mode:** Enable `Privacy Mode` from the main camera view to physically rotate the lens into the housing, disabling all video and audio recording until you turn it off.
-   **Share Device:** You can grant access to family members by going to `Device Settings > Share Device`. They will be able to view the live feed but not change critical settings.
-   **Storage Options:**
    * **Nexora Cloud:** Subscribe to a cloud plan for secure, off-site storage of event recordings.
    * **microSD Card:** Recordings are stored locally. The camera will automatically overwrite the oldest footage when the card is full.

---

## 6. In-Depth Troubleshooting

| Symptom / Error Code          | Possible Cause(s)                                                              | Solution / Action                                                                                                                                                                                                                          |
| ----------------------------- | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Camera won't power on         | Faulty power adapter, outlet, or cable connection.                             | 1. Try a different power outlet. 2. Ensure the power cable is securely plugged into both the adapter and the camera. 3. If the LED remains off, the power adapter may need replacement. Contact support.                                     |
| QR Code scan fails (Error C2) | Phone screen brightness too low/high; Lens is dirty; Distance is incorrect.      | 1. Clean the camera lens with a microfiber cloth. 2. Set your phone screen brightness to maximum. 3. Hold the phone steady 15-20 cm (6-8 inches) from the lens and slowly adjust the distance.                                             |
| Wi-Fi connection fails        | Incorrect password; Weak Wi-Fi signal; 5 GHz network selected.                 | 1. Verify your Wi-Fi password is correct. 2. Confirm you are using a **2.4 GHz network**. 3. Move your router closer to the camera or use a Wi-Fi extender. 4. Perform a factory reset by holding the reset pin for 10 seconds and try setup again. |
| Video feed is offline         | Power outage; Wi-Fi disconnection.                                              | 1. Check if the camera's LED indicator is on. If not, check the power supply. 2. Reboot your Wi-Fi router. The camera should automatically reconnect within a few minutes.                                                             |
| Night vision is blurry/dark   | Dirty lens; IR LEDs are blocked or reflecting off a nearby surface.              | 1. Clean the camera lens. 2. Ensure there are no objects (like a windowsill or soffit) within 10 cm (4 inches) of the camera that could be reflecting the infrared light back into the lens, causing glare.                                |
| Two-way audio is static/unclear | Poor network connection; Microphone/speaker is obstructed.                         | 1. Ensure a strong Wi-Fi signal at the camera's location. 2. Check that the small microphone and speaker holes on the camera body are not blocked by dust or debris.                                                                   |
| Motion alerts are too frequent/infrequent | Detection sensitivity is set incorrectly; AI zones are not configured. | 1. In the app, go to `Detection Settings` and adjust the `Motion Sensitivity` slider. 2. Set up specific `Activity Zones` to monitor only the areas you care about and ignore background movement like swaying trees.                        |
| microSD card not detected     | Card is not inserted correctly; Card is faulty, fake, or incompatible.             | 1. Power off the camera, re-insert the microSD card until it clicks, and power back on. 2. In the app, go to `Storage Settings > SD Card` and format the card. 3. Use a reputable, Class 10 or U3 rated microSD card.                     |

---

## 7. Technical Specifications
-   **Video Resolution:** 1920x1080p Full HD @ 25fps
-   **Video Compression:** H.265 / H.264
-   **Field of View:** 355° Pan, 90° Tilt
-   **Night Vision:** 8x 850nm Infrared LEDs, range up to 10m (33ft)
-   **Audio:** Integrated microphone and speaker with noise cancellation
-   **Connectivity:** Wi-Fi 802.11 b/g/n @ 2.4GHz
-   **Storage:** microSD card (up to 128GB, Class 10), Nexora Cloud
-   **Power:** 5V/2A DC Power Adapter
-   **Operating Conditions:** -20°C to 50°C (-4°F to 122°F), Weather Resistance IP65

---

## 8. Warranty & Support
-   **Warranty:** Nexora provides a **1-year limited manufacturer's warranty** from the date of purchase. This warranty covers hardware defects under normal use. It does not cover damage from power surges, water immersion, or physical tampering.
-   **Support:** For video tutorials, detailed FAQs, and warranty service, visit our support portal at **www.nexoraelectronics.com/support**. For direct assistance, call **1800-123-NEXORA**. Please have your proof of purchase and the camera's serial number (located on the bottom) ready.