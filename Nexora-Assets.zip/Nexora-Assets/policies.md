# Nexora Electronics – Official Customer Policies
**Effective Date: September 27, 2025**

_Products Covered: All Nexora-branded smart home devices, including but not limited to, Nexora Thermostat Pro, SecureSphere 360 Camera, LumiGlow Smart Lights, and associated accessories sold by Nexora or its authorized resellers._

---
## 1. Limited Warranty Policy
### 1.1. Warranty Period
All Nexora products come with a 2-year limited warranty covering manufacturing defects, effective from the original date of purchase. Accessories included in the original product package are covered for the same period.

### 1.2. Scope of Coverage
This warranty covers:
- Hardware failures resulting from defects in materials and workmanship under normal use conditions as outlined in the product's user manual.
- Firmware malfunctions that are not resolved by a user-initiated update performed according to Nexora's official instructions.

### 1.3. Exclusions from Coverage
This limited warranty does NOT cover:
- Damage caused by accident, abuse, misuse, flood, fire, earthquake, or other external causes.
- Damage caused by operating the product outside the permitted or intended uses described in the user manual.
- Cosmetic damage, including but not limited to scratches, dents, and broken plastic on ports.
- Damage caused by service (including upgrades and expansions) performed by anyone who is not an authorized representative of Nexora Electronics.
- Products that have been modified to alter functionality or capability without the written permission of Nexora.
- Consumable parts, such as batteries or protective coatings.

### 1.4. Warranty Service
To make a warranty claim, the original purchaser must contact Nexora support with the product's serial number and a valid proof of purchase. Nexora's sole obligation under this warranty shall be, at its option, to repair the product, replace it with a new or refurbished unit, or provide a refund. This warranty is non-transferable.

---
## 2. Returns, Replacements & Refunds Policy
### 2.1. 30-Day Return Policy
Products purchased directly from Nexora may be returned for a full refund within 30 days of the original purchase date, provided they are in unused, like-new condition and in their original packaging. An RMA (Return Merchandise Authorization) number must be obtained from customer support before shipping.

### 2.2. Replacement of Defective Products
Products confirmed by Nexora support to be defective under warranty will be replaced at no cost. Nexora will provide a prepaid shipping label for the return of the defective unit. Replacements are typically shipped within 7 business days of defect verification.

### 2.3. Refunds
Approved refunds are processed to the original payment method within 7–10 business days after the returned item is received and inspected. Shipping charges are non-refundable. A 15% restocking fee may apply to returns not in their original condition.

---
## 3. Privacy Policy
### 3.1. Information We Collect
- **Personal Information:** Name, email, shipping/billing address, phone number.
- **Device & Usage Information:** Product serial numbers, IP addresses, network information (WiFi SSID), device activity logs, crash logs, and settings configurations.
- **App Usage Data:** Feature usage frequency, UI interactions, and account preferences.

### 3.2. How We Use Information
- To operate, maintain, and improve our products and services.
- To provide customer support and process transactions.
- To send important notices, such as security alerts and firmware updates.
- To prevent fraud and enhance security.

### 3.3. Data Sharing & Disclosure
Nexora does not sell, rent, or trade customer personal data. Data may be shared with trusted service providers (e.g., cloud hosting, payment processing) under strict confidentiality agreements. We may disclose information if required by law.

### 3.4. Your Rights & Choices
You have the right to access, update, or delete your personal information via your Nexora account settings. You may also request a copy of your data or permanent account deletion.

---
## 4. App, Cloud & Connectivity Policy
### 4.1. System Requirements
A functioning broadband internet connection with a **2.4GHz Wi-Fi network** is required. 5GHz networks are not supported for setup. A modern iOS or Android smartphone is required for the Nexora Home App.

### 4.2. Service Availability
Nexora strives for high availability of its cloud services but does not guarantee 100% uptime. Scheduled maintenance or unforeseen outages may temporarily disrupt service.

### 4.3. Subscription Services
Cloud video storage and certain advanced AI features are available through paid subscription plans. Subscriptions are billed recurringly and can be canceled at any time, with service remaining active until the end of the current billing period.

---
## 5. End-of-Life (EOL) Policy
### 5.1. Product Support Lifecycle
Nexora commits to providing support, including critical security updates, for its products for a minimum of five (5) years from the product's official launch date.

### 5.2. EOL Process
Nexora will provide public notice on our website at least 180 days before a product reaches its End-of-Life. After this period, features dependent on cloud services may be discontinued.

---
## 6. Customer Support Policy
### 6.1. Support Channels
Customers can reach support via in-app chat, email (support@nexora.com), or our toll-free number (+1-800-NEXORA).

### 6.2. Tiers of Support
- **Tier 1 (Automated):** SentioBot provides 24/7 instant support.
- **Tier 2 (Human Agent):** For issues SentioBot cannot resolve, conversations are escalated. Our goal is a response within 24 business hours.
- **Tier 3 (Technical Specialist):** For complex hardware or network issues.

### 6.3. Hours of Operation
Human support agents are available from 6:00 AM to 6:00 PM (PST), Monday through Saturday.